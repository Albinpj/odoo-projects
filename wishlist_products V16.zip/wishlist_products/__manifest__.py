{
    'name': 'Wishlist Products',
    'version': '16.0.1.0',
    'sequence': -103,
    'category': 'Website Wishlist Products',
    'summary': 'Website Wishlist Products',
    'application': True,
    'depends': [
        'base',
        'website',
    ],
    'data': [
        # 'security/ir.model.access.csv',
        'views/product_wishlist.xml',

    ],

}
