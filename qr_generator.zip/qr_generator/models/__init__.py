from . import qr_generator_syntry
