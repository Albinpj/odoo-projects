from . import res_partner
